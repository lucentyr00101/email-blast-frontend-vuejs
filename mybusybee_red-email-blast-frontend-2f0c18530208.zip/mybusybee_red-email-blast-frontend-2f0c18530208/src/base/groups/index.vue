<template lang="pug" src="./groups.pug"></template>

<script src="./groups.js"></script>

<style lang="stylus" scoped src="./groups.styl"></style>