<template lang="pug" src="./emails.pug"></template>

<script src="./emails.js"></script>

<style lang="stylus" scoped src="./emails.styl"></style>