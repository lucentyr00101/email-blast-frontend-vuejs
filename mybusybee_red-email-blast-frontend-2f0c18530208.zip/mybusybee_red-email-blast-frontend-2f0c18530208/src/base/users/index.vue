<template lang="pug" src="./users.pug"></template>

<script src="./users.js"></script>

<style lang="stylus" scoped src="./users.styl"></style>