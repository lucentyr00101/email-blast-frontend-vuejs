<template lang="pug" src="./contacts.pug"></template>

<script src="./contacts.js"></script>

<style lang="stylus" scoped src="./contacts.styl"></style>