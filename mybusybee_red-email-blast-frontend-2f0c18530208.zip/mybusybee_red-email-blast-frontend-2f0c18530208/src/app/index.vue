<template lang="pug" src="./app.pug"></template>

<style lang="stylus" src="./app.styl"></style>

<script src="./app.js"></script>
