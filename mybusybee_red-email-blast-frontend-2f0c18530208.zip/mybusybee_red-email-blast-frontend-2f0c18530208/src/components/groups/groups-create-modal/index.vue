<template lang="pug" src="./groups-create-modal.pug"></template>

<script src="./groups-create-modal.js"></script>

<style lang="stylus" scoped src="./groups-create-modal.styl"></style>