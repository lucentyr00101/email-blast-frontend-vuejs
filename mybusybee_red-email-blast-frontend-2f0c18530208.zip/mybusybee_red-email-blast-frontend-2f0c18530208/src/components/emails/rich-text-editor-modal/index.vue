<template lang="pug" src="./rich-text-editor-modal.pug"></template>

<script src="./rich-text-editor-modal.js"></script>

<style lang="stylus" scoped src="./rich-text-editor-modal.styl"></style>