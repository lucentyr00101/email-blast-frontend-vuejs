<template lang="pug" src="./drag-and-drop-editor-modal.pug"></template>

<script src="./drag-and-drop-editor-modal.js"></script>

<style lang="stylus" scoped src="./drag-and-drop-editor-modal.styl"></style>