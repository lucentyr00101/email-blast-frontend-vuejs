export default {
    data() {
        return {
            dialog: false
        }
    }
}