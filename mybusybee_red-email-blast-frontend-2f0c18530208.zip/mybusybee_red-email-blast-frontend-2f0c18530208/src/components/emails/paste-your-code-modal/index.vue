<template lang="pug" src="./paste-your-code-modal.pug"></template>

<script src="./paste-your-code-modal.js"></script>

<style lang="stylus" scoped src="./paste-your-code-modal.styl"></style>