<template lang="pug" src="./contacts-create-modal.pug"></template>

<script src="./contacts-create-modal.js"></script>

<style lang="stylus" scoped src="./contacts-create-modal.styl"></style>