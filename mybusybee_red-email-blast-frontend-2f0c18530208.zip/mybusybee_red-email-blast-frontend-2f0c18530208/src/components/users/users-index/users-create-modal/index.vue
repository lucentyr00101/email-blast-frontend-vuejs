<template lang="pug" src="./users-create-modal.pug"></template>

<script src="./users-create-modal.js"></script>

<style lang="stylus" scoped src="./users-create-modal.styl"></style>