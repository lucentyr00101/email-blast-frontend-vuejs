<template lang="pug" src="./emails-create.pug"></template>

<script src="./emails-create.js"></script>

<style lang="stylus" scoped src="./emails-create.styl"></style>