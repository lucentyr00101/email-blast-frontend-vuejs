export default {
    components: {
        emailsCreateStepper: () => import('@/components/emails/emails-create-stepper')
    }
}