<template lang="pug" src="./emails-index.pug"></template>

<script src="./emails-index.js"></script>

<style lang="stylus" scoped src="./emails-index.styl"></style>