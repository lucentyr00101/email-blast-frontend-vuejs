<template lang="pug" src="./users-index.pug"></template>

<script src="./users-index.js"></script>

<style lang="stylus" scoped src="./users-index.styl"></style>