<template lang="pug" src="./users-edit.pug"></template>

<script src="./users-edit.js"></script>

<style lang="stylus" scoped src="./users-edit.styl"></style>