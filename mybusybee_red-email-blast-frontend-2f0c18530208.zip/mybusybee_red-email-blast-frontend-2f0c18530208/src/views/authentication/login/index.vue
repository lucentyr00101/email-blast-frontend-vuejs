<template lang="pug" src="./login.pug"></template>

<script src="./login.js"></script>

<style lang="stylus" scoped src="./login.styl"></style>