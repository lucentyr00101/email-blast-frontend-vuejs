<template lang="pug" src="./contacts-edit.pug"></template>

<script src="./contacts-edit.js"></script>

<style lang="stylus" scoped src="./contacts-edit.styl"></style>