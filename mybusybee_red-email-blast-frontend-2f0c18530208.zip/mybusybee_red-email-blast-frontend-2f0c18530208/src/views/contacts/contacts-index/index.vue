<template lang="pug" src="./contacts-index.pug"></template>

<script src="./contacts-index.js"></script>

<style lang="stylus" scoped src="./contacts-index.styl"></style>