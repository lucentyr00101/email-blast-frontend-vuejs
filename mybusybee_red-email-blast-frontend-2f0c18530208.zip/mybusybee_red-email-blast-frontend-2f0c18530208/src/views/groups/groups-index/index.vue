<template lang="pug" src="./groups-index.pug"></template>

<script src="./groups-index.js"></script>

<style lang="stylus" scoped src="./groups-index.styl"></style>