<template lang="pug" src="./groups-edit.pug"></template>

<script src="./groups-edit.js"></script>

<style lang="stylus" src="./groups-edit.styl"></style>