<template lang="pug" src="./home.pug"></template>

<script src="./home.js"></script>

<style lang="stylus" scoped src="./home.styl"></style>