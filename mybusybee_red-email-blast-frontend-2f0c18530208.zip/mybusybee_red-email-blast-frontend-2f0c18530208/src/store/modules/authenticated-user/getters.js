export const getAuthUser = state => {
    return state.authUser
}