export const setAuthUser = (state, payload) => {
    state.authUser = payload
}