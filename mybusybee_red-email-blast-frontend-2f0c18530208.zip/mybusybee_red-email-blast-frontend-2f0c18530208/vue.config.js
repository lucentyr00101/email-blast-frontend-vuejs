module.exports = {
    publicPath: '/email-blast/'
}